#PHP Developer Test - David Mann

##Usage:
Run /web/index.php in your browser.

##Notes:
In the technical requirements, it lists a "full size image" as what should be opened when clicked
but after reading the documentation it seems this is not possible on all images, I have used the 
"medium" (_z) size as this seems to be the default used.

If you would like me to do Unit tests for this, please let me know.

##Requirements:
* PHP 5.3 (Uses Namespaces)
* CURL extension (Doesn't just fail if missing)
