<?php

namespace App\Controllers;

use \App\Api\Flikr;

include(dirname(__DIR__) . '/API/Flikr.php');

class SearchController {
    
    protected $results = array();
    
    protected $api = false;
    
    public function Index() {
        return array();
    }
    
    public function search() {
        $term = $this->getRequestParameter('term');
        $page = $this->getRequestParameter('page', '1');
        
        $this->results = $this->getFlikrApi()->setPage($page)->setSearchTerm($term);
        
        $lastPage = $this->getFlikrApi()->getLastPage();
        
        return array(
            'results'  => $this->results,
            'term' 	   => $term,
            'page'     => $page,
            'lastPage' => $lastPage,
            'prevPage' => max($page - 1, 1),
            'nextPage' => min($page + 1, $lastPage)
        );
    }
    
    protected function getFlikrApi($reset = false) {
        if(!$this->api || $reset) {
            $this->api = new Flikr();
        }
        
        return $this->api;
    }
    
    public function getRequestParameter($key, $default = null) {
        return isset($_REQUEST[$key]) ? $_REQUEST[$key] : $default;        
    }
}