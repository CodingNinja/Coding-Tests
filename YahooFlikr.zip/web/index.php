<?php

// Sorry for the overkill lol. If you want Unit Tests,
// feel free to send me an email. Didn't think they
// would be relevant as it's just a test.

function getAppDir() {
    return dirname(__DIR__) .'/App/';
}

function response($view, $data) {
    extract($data);
    include(getAppDir() . 'Resources/Views/' . $view);
}
// Get the controller, defaults to Searchcontroller
$controller = ucfirst((isset($_GET['c']) ? $_GET['c'] : 'search') . 'Controller');

// Get the action, defaults to Index
$action = ucfirst(isset($_GET['a']) ? $_GET['a'] : 'index');
$data = array();

// We don't have routing so it has to be a straight match
if(file_exists($file = (getAppDir() . 'Controllers/' . $controller . '.php'))) {
     // Include the controller class
    include($file);
    // Create the controller
    $controller = 'App\\Controllers\\' . $controller;
    $controller = new $controller();
    
    $callable = array($controller, $action);
    $data = '';
    // Wrap in a try catch block so user doesn't get some horrid error
    // if somethign goes wrong
    try {
        if(is_callable($callable)) { // Yay, valid Controller / Action
                $data = call_user_func($callable);
        }else{  // Noez, they have tried to do something that we haven't linked to :(
            header('HTTP/1.0 401 Not Found');
            $action = 'NotFound';
        }
    }catch(Exception $e) { // Looks like something bad happened, let's fail gracefully
        header('HTTP/1.0 500 Server Error');
        $action = 'Error';
        $data = array('e' => $e);
    }
}else { // No controller found
    header('HTTP/1.0 401 Not Found');
    $action = 'NotFound';
}

// Get the view content
$view = $action . '.html';
ob_start();
response($view, $data);
$content = ob_get_contents();
ob_end_clean();

// Fill the layout and were done!
response('Layout.html', array('content' => $content));